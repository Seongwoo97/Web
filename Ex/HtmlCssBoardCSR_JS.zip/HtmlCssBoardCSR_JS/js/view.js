// 상세글 보기 화면은.. 목록에서 선택될 때 게시글 번호(no)를 URL로 전달받음

// url로 전달된 no 값 취득하기
// alert( window.loaction.href ); //모든 경로 나옴
// alert(window.location.search); // ? 뒤에 전달된 파라미터 값들만 선택됨

// 번호 숫자만 필요하니 '=' 글자를 기준으로 분리
var no= location.search